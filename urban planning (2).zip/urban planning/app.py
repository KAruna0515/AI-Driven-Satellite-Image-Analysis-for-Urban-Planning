import os
import numpy as np
import tensorflow as tf
from PIL import Image
import io
import base64
from flask import Flask, request, jsonify, render_template, send_from_directory
from werkzeug.utils import secure_filename
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, concatenate
from tensorflow.keras.applications import VGG16
import cv2
import random
import json

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}
app.secret_key = 'super-secret-key'

class UrbanPlanningSystem:
    def __init__(self):
        self.categories = [
            "buildings", "roads", "vegetation", "water", "open_land",
            "agricultural", "commercial", "residential", "public_spaces"
        ]
        self.category_colors = {
            "buildings": [200, 0, 0],
            "roads": [100, 100, 100],
            "vegetation": [0, 150, 0],
            "water": [0, 0, 200],
            "open_land": [210, 180, 140],
            "agricultural": [160, 210, 70],
            "commercial": [220, 60, 20],
            "residential": [250, 170, 30],
            "public_spaces": [230, 230, 0]
        }
        self.segmentation_model = self._build_segmentation_model()

    def _build_segmentation_model(self):
        inputs = Input(shape=(None, None, 3))
        base_model = VGG16(include_top=False, weights='imagenet', input_tensor=inputs)
        layer_names = ['block1_conv2', 'block2_conv2', 'block3_conv3', 'block4_conv3', 'block5_conv3']
        layers = [base_model.get_layer(name).output for name in layer_names]
        
        x = layers[-1]
        for i in range(len(layers)-2, -1, -1):
            x = UpSampling2D((2, 2))(x)
            x = Conv2D(128, (3, 3), activation='relu', padding='same')(x)
            x = concatenate([layers[i], x], axis=3)
            x = Conv2D(64, (3, 3), activation='relu', padding='same')(x)
        
        outputs = Conv2D(len(self.categories), (1, 1), activation='softmax')(x)
        model = Model(inputs=inputs, outputs=outputs)
        model.compile(optimizer='adam', loss='categorical_crossentropy')
        return model

    def analyze_image(self, image_path):
        try:
            img = np.array(Image.open(image_path).convert('RGB'))
            height, width = img.shape[:2]
        except Exception as e:
            raise ValueError(f"Error loading image: {e}")

        mask = np.zeros((height, width, len(self.categories)), dtype=np.float32)
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        
        # Water - More restrictive blue range to avoid confusion with vegetation
        lower_blue = np.array([100, 70, 50])  # More saturated blues
        upper_blue = np.array([140, 255, 255])
        water_mask = cv2.inRange(hsv, lower_blue, upper_blue)
        
        # Additional checks for water - look for dark blues in RGB
        rgb_water_lower = np.array([0, 0, 100])
        rgb_water_upper = np.array([80, 80, 255])
        rgb_water_mask = cv2.inRange(img, rgb_water_lower, rgb_water_upper)
        
        # Combine water detection methods with stricter conditions
        water_mask = cv2.bitwise_and(water_mask, rgb_water_mask)
        
        # Apply texture analysis for water (water usually has smooth texture)
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        laplacian = cv2.Laplacian(blur, cv2.CV_64F)
        smooth_mask = np.abs(laplacian) < 5  # Smooth areas have low Laplacian values
        
        # Final water mask with texture consideration
        water_mask = cv2.bitwise_and(water_mask, smooth_mask.astype(np.uint8) * 255)
        mask[:, :, self.categories.index("water")] = water_mask / 255.0
        
        # Vegetation - Improved detection for different types of green vegetation
        # For trees/forests (darker greens)
        lower_dark_green = np.array([35, 40, 20])  # Darker greens (forests)
        upper_dark_green = np.array([90, 255, 150])
        dark_vegetation_mask = cv2.inRange(hsv, lower_dark_green, upper_dark_green)
        
        # For lighter vegetation (grass, bushes)
        lower_light_green = np.array([35, 40, 150])  # Lighter greens
        upper_light_green = np.array([90, 255, 255])
        light_vegetation_mask = cv2.inRange(hsv, lower_light_green, upper_light_green)
        
        # Combine vegetation masks
        vegetation_mask = cv2.bitwise_or(dark_vegetation_mask, light_vegetation_mask)
        
        # Exclude areas already classified as water
        vegetation_mask[water_mask > 0] = 0
        
        # Add texture analysis for vegetation (less smooth than water, more varied)
        texture_variance = cv2.Sobel(gray, cv2.CV_64F, 1, 1, ksize=5)
        texture_mask = (np.abs(texture_variance) > 10).astype(np.uint8) * 255
        vegetation_mask = cv2.bitwise_and(vegetation_mask, texture_mask)
        
        mask[:, :, self.categories.index("vegetation")] = vegetation_mask / 255.0
        
        # Roads - Enhanced detection
        edges = cv2.Canny(gray, 50, 150)
        # Detect straight lines which are more likely to be roads
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=40, maxLineGap=10)
        
        # Create a blank mask for roads
        roads_mask = np.zeros((height, width), dtype=np.uint8)
        
        # Draw detected lines on the roads mask
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                cv2.line(roads_mask, (x1, y1), (x2, y2), 255, 5)
        
        # Apply morphological operations to connect nearby lines and fill gaps
        road_kernel = np.ones((7, 7), np.uint8)
        roads_mask = cv2.dilate(roads_mask, road_kernel, iterations=1)
        roads_mask = cv2.erode(roads_mask, np.ones((3, 3), np.uint8), iterations=1)
        
        # Remove road detections from vegetation and water areas
        roads_mask[vegetation_mask > 0] = 0
        roads_mask[water_mask > 0] = 0
        
        mask[:, :, self.categories.index("roads")] = roads_mask / 255.0
        
        # Buildings - Improved detection
        # Look for rectangular shapes and specific colors
        ret, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        building_kernel = np.ones((5, 5), np.uint8)
        buildings = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, building_kernel)
        
        # Detect rectangular contours which are more likely to be buildings
        contours, _ = cv2.findContours(buildings, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        building_mask = np.zeros((height, width), dtype=np.uint8)
        
        for contour in contours:
            # Filter by area to exclude very small contours
            if cv2.contourArea(contour) > 100:
                # Check if the contour approximates a rectangle
                epsilon = 0.05 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                if len(approx) >= 4 and len(approx) <= 8:  # Buildings usually have 4-8 sides
                    cv2.drawContours(building_mask, [contour], 0, 255, -1)
        
        # Remove building detections from vegetation, water, and road areas
        building_mask[vegetation_mask > 0] = 0
        building_mask[water_mask > 0] = 0
        building_mask[roads_mask > 0] = 0
        
        mask[:, :, self.categories.index("buildings")] = building_mask / 255.0
        
        # Agricultural - Detection based on patterns and colors
        # Agricultural land often has regular patterns and specific colors
        agri_lower_hsv = np.array([20, 40, 100])  # Yellowish/light greenish
        agri_upper_hsv = np.array([35, 255, 255])
        agricultural_mask = cv2.inRange(hsv, agri_lower_hsv, agri_upper_hsv)
        
        # Exclude areas already classified
        agricultural_mask[vegetation_mask > 0] = 0
        agricultural_mask[water_mask > 0] = 0
        agricultural_mask[roads_mask > 0] = 0
        agricultural_mask[building_mask > 0] = 0
        
        mask[:, :, self.categories.index("agricultural")] = agricultural_mask / 255.0
        
        # Commercial areas - typically near roads and with specific building patterns
        commercial_mask = np.zeros((height, width), dtype=np.uint8)
        road_proximity = cv2.dilate(roads_mask, np.ones((15, 15), np.uint8), iterations=1)
        building_proximity = cv2.dilate(building_mask, np.ones((10, 10), np.uint8), iterations=1)
        
        # Commercial areas are usually dense buildings near roads
        commercial_candidates = cv2.bitwise_and(road_proximity, building_proximity)
        commercial_mask[commercial_candidates > 0] = 255
        
        # Exclude areas already strongly classified
        commercial_mask[water_mask > 0] = 0
        commercial_mask[vegetation_mask > 100] = 0  # Allow some overlap with sparse vegetation
        
        mask[:, :, self.categories.index("commercial")] = commercial_mask / 255.0
        
        # Residential areas - typically more spread out than commercial
        residential_mask = np.zeros((height, width), dtype=np.uint8)
        # Residential areas often have buildings with nearby vegetation
        residential_candidates = cv2.dilate(building_mask, np.ones((20, 20), np.uint8), iterations=1)
        residential_mask[residential_candidates > 0] = 255
        
        # Exclude commercial areas and other strongly classified areas
        residential_mask[commercial_mask > 0] = 0
        residential_mask[water_mask > 0] = 0
        residential_mask[vegetation_mask > 100] = 0  # Allow some overlap with sparse vegetation
        residential_mask[roads_mask > 0] = 0
        
        mask[:, :, self.categories.index("residential")] = residential_mask / 255.0
        
        # Public spaces - parks, plazas, etc.
        public_spaces_mask = np.zeros((height, width), dtype=np.uint8)
        # Public spaces often have a mix of vegetation and open spaces near residential areas
        vegetation_proximity = cv2.dilate(vegetation_mask, np.ones((15, 15), np.uint8), iterations=1)
        residential_proximity = cv2.dilate(residential_mask, np.ones((20, 20), np.uint8), iterations=1)
        
        public_candidates = cv2.bitwise_and(vegetation_proximity, residential_proximity)
        public_spaces_mask[public_candidates > 0] = 255
        
        # Exclude already classified areas
        public_spaces_mask[water_mask > 0] = 0
        public_spaces_mask[roads_mask > 0] = 0
        public_spaces_mask[building_mask > 0] = 0
        public_spaces_mask[commercial_mask > 0] = 0
        public_spaces_mask[residential_mask > 0] = 0
        public_spaces_mask[vegetation_mask > 100] = 0  # Don't classify dense vegetation as public space
        
        mask[:, :, self.categories.index("public_spaces")] = public_spaces_mask / 255.0
        
        # Open land - areas not classified as anything else
        assigned = np.sum(mask, axis=2)
        open_land = np.where(assigned < 0.2, 1.0, 0.0)
        mask[:, :, self.categories.index("open_land")] = open_land
        
        # Create final segmentation map
        segmentation_map = np.argmax(mask, axis=2)
        
        # Statistics
        stats = {}
        total_pixels = height * width
        for i, category in enumerate(self.categories):
            pixels = np.sum(segmentation_map == i)
            stats[category] = {
                "pixels": int(pixels),
                "percentage": (pixels / total_pixels) * 100
            }

        # Segmentation image
        seg_image = np.zeros((height, width, 3), dtype=np.uint8)
        for i, category in enumerate(self.categories):
            seg_image[segmentation_map == i] = self.category_colors[category]
        
        buff = io.BytesIO()
        Image.fromarray(seg_image).save(buff, format='PNG')
        encoded_seg = base64.b64encode(buff.getvalue()).decode('utf-8')

        return {
            "stats": stats,
            "segmentation_image": encoded_seg,
            "width": width,
            "height": height,
            "segmentation_map": segmentation_map.tolist()
        }

    def generate_urban_plans(self, analysis_results, num_plans=3):
        width = analysis_results["width"]
        height = analysis_results["height"]
        segmentation_map = np.array(analysis_results["segmentation_map"])
        plans = []
        
        for plan_idx in range(num_plans):
            if plan_idx == 0:
                new_map = self._apply_green_city_plan(segmentation_map)
                description = "Green City: Prioritizes parks and pedestrian areas"
            elif plan_idx == 1:
                new_map = self._apply_economic_development_plan(segmentation_map)
                description = "Economic Growth: Maximizes housing and commercial space"
            else:
                new_map = self._apply_balanced_plan(segmentation_map)
                description = "Balanced Development: Equal focus on all aspects"
            
            plan_image = np.zeros((height, width, 3), dtype=np.uint8)
            for i, category in enumerate(self.categories):
                plan_image[new_map == i] = self.category_colors[category]
            
            buff = io.BytesIO()
            Image.fromarray(plan_image).save(buff, format='PNG')
            encoded_plan = base64.b64encode(buff.getvalue()).decode('utf-8')
            
            stats = {}
            total_pixels = height * width
            for i, category in enumerate(self.categories):
                pixels = np.sum(new_map == i)
                stats[category] = {
                    "pixels": int(pixels),
                    "percentage": (pixels / total_pixels) * 100
                }
            
            plans.append({
                "name": f"Plan {plan_idx + 1}",
                "description": description,
                "image": encoded_plan,
                "stats": stats
            })
        
        return plans

    def _apply_green_city_plan(self, segmentation_map):
        """Apply green city planning strategy"""
        height, width = segmentation_map.shape
        new_map = segmentation_map.copy()
        
        # Expand vegetation around existing green areas
        vegetation_idx = self.categories.index("vegetation")
        open_land_idx = self.categories.index("open_land")
        
        # Find existing vegetation
        vegetation_mask = (segmentation_map == vegetation_idx)
        
        # Create a dilation kernel
        kernel = np.ones((15, 15), np.uint8)
        
        # Dilate the vegetation mask to expand green areas
        expanded_vegetation = cv2.dilate(vegetation_mask.astype(np.uint8), kernel, iterations=1)
        
        # Apply the expanded vegetation only to open land
        for i in range(height):
            for j in range(width):
                if expanded_vegetation[i, j] > 0 and segmentation_map[i, j] == open_land_idx:
                    new_map[i, j] = vegetation_idx
        
        # Add public spaces near residential areas
        building_idx = self.categories.index("buildings")
        public_spaces_idx = self.categories.index("public_spaces")
        
        # Find buildings that could be converted to mixed-use
        buildings_mask = (segmentation_map == building_idx)
        
        # Create public spaces around building clusters
        public_spaces = cv2.dilate(buildings_mask.astype(np.uint8), np.ones((10, 10), np.uint8), iterations=1)
        public_spaces = public_spaces & (segmentation_map == open_land_idx).astype(np.uint8)
        
        # Apply public spaces
        new_map[public_spaces > 0] = public_spaces_idx
        
        # Enhance road network for better connectivity
        roads_idx = self.categories.index("roads")
        
        # Create a more organized road grid
        for i in range(50, height, 100):
            road_width = 5
            # Horizontal roads
            new_map[max(0, i-road_width//2):min(height, i+road_width//2), :] = roads_idx
        
        for j in range(50, width, 100):
            road_width = 5
            # Vertical roads
            new_map[:, max(0, j-road_width//2):min(width, j+road_width//2)] = roads_idx
        
        # Make sure water bodies are preserved
        water_idx = self.categories.index("water")
        new_map[segmentation_map == water_idx] = water_idx
        
        # Convert some open land to residential and commercial
        residential_idx = self.categories.index("residential")
        commercial_idx = self.categories.index("commercial")
        
        # Find remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Convert some to residential
        residential_mask = np.zeros_like(remaining_open)
        num_residential_clusters = 5
        for _ in range(num_residential_clusters):
            # Find a random seed point in open land
            open_coords = np.where(remaining_open)
            if len(open_coords[0]) > 0:
                idx = np.random.randint(0, len(open_coords[0]))
                seed_i, seed_j = open_coords[0][idx], open_coords[1][idx]
                
                # Create a cluster around this point
                for i in range(max(0, seed_i - 20), min(height, seed_i + 20)):
                    for j in range(max(0, seed_j - 20), min(width, seed_j + 20)):
                        if remaining_open[i, j] and np.random.random() < 0.7:
                            residential_mask[i, j] = 1
        
        # Apply residential areas
        new_map[residential_mask == 1] = residential_idx
        
        # Update remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Convert some to commercial, preferably near roads
        roads_expanded = cv2.dilate((new_map == roads_idx).astype(np.uint8), np.ones((10, 10), np.uint8), iterations=1)
        commercial_candidates = (remaining_open & (roads_expanded > 0))
        
        # Apply commercial areas
        commercial_mask = np.zeros_like(commercial_candidates)
        commercial_candidates_coords = np.where(commercial_candidates)
        if len(commercial_candidates_coords[0]) > 0:
            # Take a random subset of the candidates
            indices = np.random.choice(
                len(commercial_candidates_coords[0]),
                size=min(1000, len(commercial_candidates_coords[0])),
                replace=False
            )
            for idx in indices:
                i, j = commercial_candidates_coords[0][idx], commercial_candidates_coords[1][idx]
                commercial_mask[i, j] = 1
        
        new_map[commercial_mask == 1] = commercial_idx
        
        return new_map
    
    def _apply_economic_development_plan(self, segmentation_map):
        """Apply economic development planning strategy"""
        height, width = segmentation_map.shape
        new_map = segmentation_map.copy()
        
        # Identify indices for each category
        open_land_idx = self.categories.index("open_land")
        residential_idx = self.categories.index("residential")
        commercial_idx = self.categories.index("commercial")
        roads_idx = self.categories.index("roads")
        water_idx = self.categories.index("water")
        vegetation_idx = self.categories.index("vegetation")
        
        # Preserve existing water bodies
        water_mask = (segmentation_map == water_idx)
        
        # Keep only minimal vegetation (reduce by 50%)
        vegetation_mask = (segmentation_map == vegetation_idx)
        vegetation_pixels = np.where(vegetation_mask)
        if len(vegetation_pixels[0]) > 0:  # Check if there's any vegetation
            to_convert = np.random.choice(len(vegetation_pixels[0]), size=len(vegetation_pixels[0])//2, replace=False)
            for idx in to_convert:
                i, j = vegetation_pixels[0][idx], vegetation_pixels[1][idx]
                new_map[i, j] = open_land_idx
        
        # Enhance road network for better connectivity - wider roads
        existing_roads = (segmentation_map == roads_idx)
        expanded_roads = cv2.dilate(existing_roads.astype(np.uint8), np.ones((7, 7), np.uint8), iterations=1)
        
        # Create a grid of roads
        for i in range(40, height, 80):
            road_width = 8
            # Horizontal roads
            new_map[max(0, i-road_width//2):min(height, i+road_width//2), :] = roads_idx
        
        for j in range(40, width, 80):
            road_width = 8
            # Vertical roads
            new_map[:, max(0, j-road_width//2):min(width, j+road_width//2)] = roads_idx
        
        # Make sure water bodies are preserved
        new_map[water_mask] = water_idx
        
        # Find remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Convert a large portion to residential
        residential_areas = np.zeros_like(remaining_open)
        remaining_open_coords = np.where(remaining_open)
        if len(remaining_open_coords[0]) > 0:
            # Take 60% of open land for residential
            indices = np.random.choice(
                len(remaining_open_coords[0]),
                size=int(len(remaining_open_coords[0]) * 0.6),
                replace=False
            )
            for idx in indices:
                i, j = remaining_open_coords[0][idx], remaining_open_coords[1][idx]
                residential_areas[i, j] = 1
        
        new_map[residential_areas == 1] = residential_idx
        
        # Update remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Convert a good portion of remaining land to commercial
        # Focus commercial development near roads
        roads_proximity = cv2.dilate((new_map == roads_idx).astype(np.uint8), np.ones((15, 15), np.uint8), iterations=1)
        commercial_candidates = (remaining_open & (roads_proximity > 0))
        
        commercial_areas = np.zeros_like(commercial_candidates)
        commercial_candidates_coords = np.where(commercial_candidates)
        if len(commercial_candidates_coords[0]) > 0:
            # Take 80% of candidates for commercial
            indices = np.random.choice(
                len(commercial_candidates_coords[0]),
                size=int(len(commercial_candidates_coords[0]) * 0.8),
                replace=False
            )
            for idx in indices:
                i, j = commercial_candidates_coords[0][idx], commercial_candidates_coords[1][idx]
                commercial_areas[i, j] = 1
        
        new_map[commercial_areas == 1] = commercial_idx
        
        # Add some small parks/vegetation areas for minimal green space
        remaining_open = (new_map == open_land_idx)
        park_areas = np.zeros_like(remaining_open)
        remaining_open_coords = np.where(remaining_open)
        
        if len(remaining_open_coords[0]) > 0:
            # Create a few small parks
            for _ in range(5):
                if len(remaining_open_coords[0]) > 0:
                    idx = np.random.randint(0, len(remaining_open_coords[0]))
                    seed_i, seed_j = remaining_open_coords[0][idx], remaining_open_coords[1][idx]
                    
                    # Create a small park
                    park_size = 10
                    for i in range(max(0, seed_i - park_size), min(height, seed_i + park_size)):
                        for j in range(max(0, seed_j - park_size), min(width, seed_j + park_size)):
                            if remaining_open[i, j] and np.random.random() < 0.7:
                                park_areas[i, j] = 1
        
        new_map[park_areas == 1] = vegetation_idx
        
        return new_map
    
    def _apply_balanced_plan(self, segmentation_map):
        """Apply balanced development planning strategy"""
        height, width = segmentation_map.shape
        new_map = segmentation_map.copy()
        
        # Identify indices for each category
        open_land_idx = self.categories.index("open_land")
        residential_idx = self.categories.index("residential")
        commercial_idx = self.categories.index("commercial")
        roads_idx = self.categories.index("roads")
        water_idx = self.categories.index("water")
        vegetation_idx = self.categories.index("vegetation")
        public_spaces_idx = self.categories.index("public_spaces")
        
        # Preserve existing water bodies and most vegetation
        water_mask = (segmentation_map == water_idx)
        vegetation_mask = (segmentation_map == vegetation_idx)
        
        # Create a balanced road network
        for i in range(45, height, 90):
            road_width = 6
            # Horizontal roads
            new_map[max(0, i-road_width//2):min(height, i+road_width//2), :] = roads_idx
        
        for j in range(45, width, 90):
            road_width = 6
            # Vertical roads
            new_map[:, max(0, j-road_width//2):min(width, j+road_width//2)] = roads_idx
        
        # Make sure water bodies and vegetation are preserved
        new_map[water_mask] = water_idx
        new_map[vegetation_mask] = vegetation_idx
        
        # Expand vegetation slightly for green corridors
        expanded_vegetation = cv2.dilate(vegetation_mask.astype(np.uint8), np.ones((5, 5), np.uint8), iterations=1)
        green_corridor_mask = expanded_vegetation & (new_map == open_land_idx)
        new_map[green_corridor_mask > 0] = vegetation_idx
        
        # Find remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Create mixed-use areas with both residential and commercial
        # First, define areas for residential
        residential_areas = np.zeros_like(remaining_open)
        remaining_open_coords = np.where(remaining_open)
        if len(remaining_open_coords[0]) > 0:
            # Take 40% of open land for residential
            indices = np.random.choice(
                len(remaining_open_coords[0]),
                size=int(len(remaining_open_coords[0]) * 0.4),
                replace=False
            )
            for idx in indices:
                i, j = remaining_open_coords[0][idx], remaining_open_coords[1][idx]
                residential_areas[i, j] = 1
        
        new_map[residential_areas == 1] = residential_idx
        
        # Update remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Commercial areas preferably near roads
        roads_proximity = cv2.dilate((new_map == roads_idx).astype(np.uint8), np.ones((12, 12), np.uint8), iterations=1)
        commercial_candidates = (remaining_open & (roads_proximity > 0))
        
        commercial_areas = np.zeros_like(commercial_candidates)
        commercial_candidates_coords = np.where(commercial_candidates)
        if len(commercial_candidates_coords[0]) > 0:
            # Take 50% of candidates for commercial
            indices = np.random.choice(
                len(commercial_candidates_coords[0]),
                size=int(len(commercial_candidates_coords[0]) * 0.5),
                replace=False
            )
            for idx in indices:
                i, j = commercial_candidates_coords[0][idx], commercial_candidates_coords[1][idx]
                commercial_areas[i, j] = 1
        
        new_map[commercial_areas == 1] = commercial_idx
        
        # Update remaining open land
        remaining_open = (new_map == open_land_idx)
        
        # Add public spaces evenly distributed
        for i in range(30, height, 120):
            for j in range(30, width, 120):
                # Create a public space near these coordinates if possible
                public_space_size = 15
                for y in range(max(0, i - public_space_size), min(height, i + public_space_size)):
                    for x in range(max(0, j - public_space_size), min(width, j + public_space_size)):
                        # Only use open land for public spaces
                        if new_map[y, x] == open_land_idx and np.random.random() < 0.7:
                            new_map[y, x] = public_spaces_idx
        
        # Add more small parks/vegetation in remaining areas
        remaining_open = (new_map == open_land_idx)
        park_areas = np.zeros_like(remaining_open)
        remaining_open_coords = np.where(remaining_open)
        
        if len(remaining_open_coords[0]) > 0:
            # Take 30% of remaining open land for small parks
            indices = np.random.choice(
                len(remaining_open_coords[0]),
                size=int(len(remaining_open_coords[0]) * 0.3),
                replace=False
            )
            for idx in indices:
                i, j = remaining_open_coords[0][idx], remaining_open_coords[1][idx]
                park_areas[i, j] = 1
        
        new_map[park_areas == 1] = vegetation_idx
        
        return new_map

    def create_report_html(self, original_img, analysis, plans):
        return render_template('report.html',
            original_image=original_img,
            analysis=analysis,
            plans=plans,
            category_colors=self.category_colors,
            categories=self.categories
        )

urban_planner = UrbanPlanningSystem()

class UrbanPlanningSystem:
    def __init__(self):
        # Update categories and colors to match examples
        self.categories = [
            "industrial", "shopping", "school", "temple", "main_road",
            "residential", "public_spaces", "water", "vegetation", "open_land"
        ]
        self.category_colors = {
            "industrial": [128, 128, 128],
            "shopping": [255, 0, 255],
            "school": [0, 255, 255],
            "temple": [255, 255, 0],
            "main_road": [64, 64, 64],
            "residential": [250, 170, 30],
            "public_spaces": [230, 230, 0],
            "water": [0, 0, 200],
            "vegetation": [0, 150, 0],
            "open_land": [210, 180, 140]
        }
        self.segmentation_model = self._build_segmentation_model()
        self.sketch_model = self._build_sketch_model()

def _build_sketch_model(self):
        """Deep learning model for sketch generation"""
        model = tf.keras.Sequential([
            tf.keras.layers.Conv2D(32, (3,3), activation='relu', input_shape=(256,256,3)),
            tf.keras.layers.MaxPooling2D(2,2),
            tf.keras.layers.Conv2D(64, (3,3), activation='relu'),
            tf.keras.layers.UpSampling2D(2),
            tf.keras.layers.Conv2D(3, (3,3), activation='sigmoid', padding='same')
        ])
        model.compile(optimizer='adam', loss='mse')
        return model

def _generate_sketch_effect(self, image):
        """Apply deep learning based sketch effect"""
        resized_img = cv2.resize(image, (256, 256))
        sketch = self.sketch_model.predict(np.expand_dims(resized_img/255.0, axis=0))[0]
        sketch = (sketch * 255).astype(np.uint8)
        return cv2.resize(sketch, (image.shape[1], image.shape[0]))

def _add_annotations(self, image, segmentation_map):
        """Add text labels to different regions"""
        annotated = image.copy()
        height, width = segmentation_map.shape
        
        # Find clusters for annotation
        for i in range(0, height, 50):
            for j in range(0, width, 50):
                region = segmentation_map[i:i+50, j:j+50]
                unique, counts = np.unique(region, return_counts=True)
                if len(unique) > 0:
                    main_category = unique[np.argmax(counts)]
                    label = self.categories[main_category].upper()
                    
                    # Calculate position
                    x = j + 15
                    y = i + 35
                    
                    # Add text background
                    cv2.rectangle(annotated, (x-5, y-20), (x+len(label)*10, y+5), 
                                 (255,255,255), -1)
                    # Add text
                    cv2.putText(annotated, label, (x, y), 
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,0), 1)
        return annotated

def _generate_dynamic_layout(self, segmentation_map):
        """Create random layout based on probabilistic rules"""
        height, width = segmentation_map.shape
        new_map = np.zeros_like(segmentation_map)
        
        # Probability distribution for different zones
        zone_probs = {
            'industrial': 0.15,
            'shopping': 0.2,
            'school': 0.1,
            'temple': 0.05,
            'main_road': 0.2,
            'residential': 0.3,
            'public_spaces': 0.15,
            'water': 0.05,
            'vegetation': 0.2
        }

        for i in range(height):
            for j in range(width):
                if segmentation_map[i,j] == self.categories.index('open_land'):
                    # Randomly assign zone based on probabilities
                    choices = list(zone_probs.keys())
                    probs = [zone_probs[zone] for zone in choices]
                    selected = random.choices(choices, weights=probs, k=1)[0]
                    new_map[i,j] = self.categories.index(selected)
                else:
                    new_map[i,j] = segmentation_map[i,j]

        # Add random road patterns
        if random.random() > 0.5:
            road_width = random.randint(3,7)
            spacing = random.randint(50,150)
            for x in range(0, width, spacing):
                new_map[:, x-road_width//2:x+road_width//2] = self.categories.index('main_road')

        return new_map

def generate_urban_plans(self, analysis_results, num_plans=3):
        width = analysis_results["width"]
        height = analysis_results["height"]
        segmentation_map = np.array(analysis_results["segmentation_map"])
        plans = []
        
        for plan_idx in range(num_plans):
            # Generate dynamic layout
            dynamic_map = self._generate_dynamic_layout(segmentation_map)
            
            # Create colored map
            plan_image = np.zeros((height, width, 3), dtype=np.uint8)
            for i, category in enumerate(self.categories):
                plan_image[dynamic_map == i] = self.category_colors[category]
            
            # Apply sketch effect
            sketch_image = self._generate_sketch_effect(plan_image)
            
            # Add annotations
            annotated_image = self._add_annotations(sketch_image, dynamic_map)

            # Convert to base64
            buff = io.BytesIO()
            Image.fromarray(annotated_image).save(buff, format='PNG')
            encoded_plan = base64.b64encode(buff.getvalue()).decode('utf-8')
            
            # Calculate statistics
            stats = {}
            total_pixels = height * width
            for i, category in enumerate(self.categories):
                pixels = np.sum(dynamic_map == i)
                stats[category] = {
                    "pixels": int(pixels),
                    "percentage": (pixels / total_pixels) * 100
                }
            
            plans.append({
                "name": f"Dynamic Plan {plan_idx + 1}",
                "description": "AI-Generated Urban Sketch",
                "image": encoded_plan,
                "stats": stats
            })
        
        return plans

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'file' not in request.files:
        return render_template('index.html', error='No file uploaded')
    
    file = request.files['file']
    if file.filename == '':
        return render_template('index.html', error='No selected file')
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            analysis = urban_planner.analyze_image(filepath)
            plans = urban_planner.generate_urban_plans(analysis)
            
            # Encode original image
            with open(filepath, "rb") as img_file:
                original_img = base64.b64encode(img_file.read()).decode('utf-8')
            
            report_html = urban_planner.create_report_html(original_img, analysis, plans)
            return report_html
        except Exception as e:
            return render_template('index.html', error=str(e))
    
    return render_template('index.html', error='Invalid file type')

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)